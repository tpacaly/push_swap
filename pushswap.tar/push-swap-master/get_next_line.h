/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/15 02:54:15 by tpacaly           #+#    #+#             */
/*   Updated: 2017/05/15 03:30:53 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include "libft/libft.h"

# define BUFF_SIZE 8
# define MAX_FD 2048

typedef struct	s_sttc
{
	char		*s;
	char		*s0;
	int			a;
	int			a0;
	long long	m;
}				t_sttc;

int				get_next_line(const int fd, char **line);
#endif
