/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 12:05:46 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 12:05:47 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_H
# define STACK_H
# include <stdlib.h>
# include "libft.h"

typedef struct	s_stack
{
	int			*array;
	int			max_size;
	int			size;
	int			top;
	int			min;
	int			max;
	int			med;
}				t_stack;

int				push(t_stack *stack, int value);
int				pop(t_stack *stack, int *value);
t_stack			*create_stack(int *array, int size);
void			*free_stack(t_stack *stack);

#endif
