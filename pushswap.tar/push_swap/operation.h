/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operation.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 12:04:38 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 12:04:41 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OPERATION_H
# define OPERATION_H
# include "libft.h"

int		execute(const char *op, t_stack *a, t_stack *b);
int		do_swap(t_stack *stack);
int		do_push(t_stack *x, t_stack *y);
int		do_rotate(t_stack *stack, int d);

#endif
