#!/bin/bash
while true
do
	leaks checker
done
