/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/16 22:23:16 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/16 22:26:45 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# define LBITS 0x101010101010101L
# define HBITS 0x8080808080808080L
# define MAX(a, b)		b & ((a - b) >> 31) | a & (~(a - b) >> 31)
# define MIN(a, b)		a & ((a - b) >> 31) | b & (~(a - b) >> 31)
# define ABS(a)			(a < 0) ? -a : a
# define DABS(a)		(a < 0.0f) ? -a : a
# define STRERR			strerror
# define BLANK(c) (c == ' ' || c == '\t' || c == '\v' || c == '\r' || c == '\n')

# define PF_RED			"\033[31m"
# define PF_GREEN		"\033[32m"
# define PF_YELLOW		"\033[33m"
# define PF_BLUE		"\033[34m"
# define PF_PURPLE		"\033[35m"
# define PF_CYAN		"\033[36m"
# define PF_EOC			"\033[0m"
# define F_SHARP		(1 << 0)
# define F_SPACE		(1 << 1)
# define F_PLUS			(1 << 2)
# define F_MINUS		(1 << 3)
# define F_ZERO			(1 << 4)
# define F_WILDCARD		(1 << 5)
# define F_UPCASE		(1 << 6)
# define F_SHORT		(1 << 7)
# define F_SHORT2		(1 << 8)
# define F_LONG			(1 << 9)
# define F_LONG2		(1 << 10)
# define F_INTMAX		(1 << 11)
# define F_SIZE_T		(1 << 12)
# define F_MIN_LEN		(1 << 13)
# define F_APP_PRECI	(1 << 14)
# define F_POINTER		(1 << 15)
# define PF_BUF_SIZE	64
# include <unistd.h>
# include <string.h>
# include <stdlib.h>
# include <fcntl.h>
# include <wchar.h>
# include <stdarg.h>
# include <errno.h>

typedef struct			s_printf
{
	int					len;
	short				f;
	short				n;
	int					min_length;
	int					precision;
	int					padding;
	int					printed;
	int					fd;
	int					buffer_index;
	char				buff[PF_BUF_SIZE];
	va_list				ap;
	char				*format;
	unsigned			c;
}						t_printf;

int						ft_printf(const char *format, ...);
int						ft_dprintf(int fd, const char *format, ...);

void					parse_optionals(t_printf *p);
void					cs_not_found(t_printf *p);

void					pf_putnb(t_printf *p);
void					pf_putnb_base(int base, t_printf *p);
void					itoa_printf(intmax_t d, t_printf *p, int len);
void					itoa_base_printf(uintmax_t d, int b, t_printf *p);
void					itoa_base_fill(uintmax_t tmp, int base, char *str,
		t_printf *p);

void					pf_putstr(t_printf *p);
void					pf_putwstr(t_printf *p);
void					pf_character(t_printf *p, unsigned c);
void					ft_printf_putstr(char *s, t_printf *p);
void					pf_putwchar(t_printf *p, unsigned int w, int wl, int n);

void					print_pointer_address(t_printf *p);
void					color(t_printf *p);
void					pf_putdouble(t_printf *p);

void					buffer(t_printf *p, void *new_elem, size_t size);
void					buffer_flush(t_printf *p);

void					padding(t_printf *p, int n);

unsigned long long		ft_atoi(char *str);
void					ft_bzero(void *s, size_t n);

void					*ft_memchr(const void *mem, const unsigned char c,
		size_t n);
void					*ft_memcpy(void *dest, const void *src, size_t n);
void					*ft_memset(void *s, int c, size_t n);

double					ft_pow(double n, int pow);

char					*ft_strchr(const char *s, int c);
int						ft_strchri(char *s, int c, int i);
int						ft_strchri_lu(char *s, int c, int i);

size_t					ft_strlen(const char *str);

int						ft_strncmp(const char *s1, const char *s2, size_t n);
int						ft_strcmp(const char *s1, const char *s2);
size_t					ft_wcharlen(unsigned c);
size_t					ft_wstrlen(unsigned *s);

void					ft_strdel(char **as);
void					ft_memdel(void **ap);
char					*ft_strdup(const char *s1);
char					**ft_strsplit(char const *s, char c);
char					*ft_itoa(int n);
void					*ft_memalloc(size_t size);
int						ft_find_min_max(int *array, int size, int *min,
	int *max);
int						get_next_line(const int fd, char **line);
char					*ft_strcat(char *dest, const char *src);
char					*ft_strcpy(char *dest, const char *src);
char					*ft_strncat(char *dest, const char *src, size_t n);
char					**ft_split(char *line, int len, int *words);
char					*ft_strnew(size_t size);
int						ft_abs(int n);
#endif
