/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_min_max.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 11:25:19 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 11:29:11 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_find_min_max(int *array, int size, int *min, int *max)
{
	int		i;

	if (array == NULL || size <= 0)
		return (1);
	*min = 2147483647;
	*max = -2147483648;
	i = size;
	while (--i >= 0)
	{
		if (array[i] > *max)
			*max = array[i];
		if (array[i] < *min)
			*min = array[i];
	}
	return (0);
}
