/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/15 02:54:15 by tpacaly           #+#    #+#             */
/*   Updated: 2017/05/15 03:30:53 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H
# define BUFF_SIZE 1024
# include "libft.h"

typedef struct	s_fd
{
	int			fd;
	int			i;
	int			size;
	char		*buf;
	struct s_fd	*next;
}				t_fd;

int				free_gnl(t_fd **list);
#endif
