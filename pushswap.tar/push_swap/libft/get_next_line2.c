/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 11:57:55 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 11:58:23 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include "libft.h"

int		free_gnl(t_fd **list)
{
	t_fd	*current;
	t_fd	*n;

	current = *list;
	while (current)
	{
		if (current->buf)
			free(current->buf);
		n = current->next;
		free(current);
		current = n;
	}
	*list = NULL;
	return (-1);
}
