/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 11:20:59 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 11:21:00 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHECKER_H
# define CHECKER_H
# include "libft.h"
# include "stack.h"
# include "utils.h"
# include "parse.h"
# include "operation.h"
# define FLAG_V 1
# define FLAG_C 2
# define FLAG_I 4
# define FLAG_O 8
# define FLAG_N 16
# define FLAG_D 32
# define GTR(a, b) ((a > b) ? a : b)

int					checker(t_stack *a, t_stack *b, int fd, t_flag *flag);

#endif
