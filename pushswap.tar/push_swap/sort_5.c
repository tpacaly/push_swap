/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_5.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 12:06:17 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 12:06:19 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

static void	push_back_to_a(t_stack *a, t_stack *b, t_oplst ***cur)
{
	while (a->size != 2)
		if (HEAD(a, 0) > HEAD(a, 1))
		{
			do_op(a, b, cur, "sa");
			do_op(a, b, cur, "pb");
		}
		else
			do_op(a, b, cur, "pb");
	sort_rev_3(b, cur);
	do_op(a, b, cur, "pa");
	do_op(a, b, cur, "pa");
	do_op(a, b, cur, "pa");
}

void		sort_5(t_stack *a, t_oplst **lst, t_flag *f)
{
	t_stack	*b;
	t_oplst	**cur;
	int		pmax;
	int		maxx;

	cur = lst;
	b = create_stack(NULL, a->size);
	set_max_maxx(a, f, &maxx, &pmax);
	while (TAIL(a, 0) != f->max)
	{
		if (HEAD(a, 0) != f->max && HEAD(a, 0) != maxx &&
									HEAD(a, 0) > HEAD(a, 1))
			do_op(a, b, &cur, "sa");
		else if (HEAD(a, 0) < HEAD(a, 1) &&
				!(HEAD(a, 1) == f->max && HEAD(a, 0) == maxx))
			do_op(a, b, &cur, "pb");
		else
			do_op(a, NULL, &cur, pmax <= 2 ? "ra" : "rra");
	}
	push_back_to_a(a, b, &cur);
	free_stack(b);
}
