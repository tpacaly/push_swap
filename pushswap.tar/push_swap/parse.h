/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/22 12:04:49 by tpacaly           #+#    #+#             */
/*   Updated: 2018/02/22 12:04:50 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSE_H
# define PARSE_H
# include "stack.h"
# include "utils.h"

t_flag	*parse_argument(int argc, char **argv, const char *flags);
t_stack	*parse_number(char **argv, t_flag *f, int i);

#endif
