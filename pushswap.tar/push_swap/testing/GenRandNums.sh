python rand.py | tr '\n' ' ' | awk '{$1=$1};1'
